"""
utils/training_loops.py
-----------------------
Fungsi-fungsi reusable untuk training, validasi, dan evaluasi model.
"""

import time
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix
import os


# ── Training Loop ──────────────────────────────────────────────────────────────

def train_one_epoch(model, loader, criterion, optimizer, device):
    """
    Jalankan satu epoch training.

    Returns:
        avg_loss (float): rata-rata loss seluruh batch
        accuracy (float): akurasi pada data training
    """
    model.train()
    total_loss = 0.0
    correct = 0
    total = 0

    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)

        # Forward pass
        logits = model(xb)
        loss = criterion(logits, yb)

        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Statistik
        total_loss += loss.item() * xb.size(0)
        _, preds = torch.max(logits, 1)
        correct += (preds == yb).sum().item()
        total += yb.size(0)

    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader, device):
    """
    Evaluasi model tanpa gradient update.

    Returns:
        accuracy (float): akurasi pada dataset loader
        avg_loss (float): rata-rata loss
        all_preds (list): semua prediksi
        all_labels (list): semua label ground truth
    """
    model.eval()
    criterion = nn.CrossEntropyLoss()
    total_loss = 0.0
    correct = 0
    total = 0
    all_preds = []
    all_labels = []

    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        logits = model(xb)
        loss = criterion(logits, yb)

        total_loss += loss.item() * xb.size(0)
        _, preds = torch.max(logits, 1)
        correct += (preds == yb).sum().item()
        total += yb.size(0)
        all_preds.extend(preds.cpu().tolist())
        all_labels.extend(yb.cpu().tolist())

    return correct / total, total_loss / total, all_preds, all_labels


# ── Full Training Loop ─────────────────────────────────────────────────────────

def train_model(model, train_loader, val_loader, criterion, optimizer,
                num_epochs, device, save_path=None, scheduler=None):
    """
    Loop training lengkap dengan validasi per epoch.

    Returns:
        history (dict): berisi 'train_loss', 'train_acc', 'val_loss', 'val_acc'
    """
    history = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
    best_val_acc = 0.0

    print(f"\n{'='*60}")
    print(f"  Training mulai | Device: {device}")
    print(f"  Epochs: {num_epochs} | Save: {save_path}")
    print(f"{'='*60}\n")

    for epoch in range(1, num_epochs + 1):
        t0 = time.time()

        # Training
        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device
        )

        # Validasi
        val_acc, val_loss, _, _ = evaluate(model, val_loader, device)

        # Scheduler step (jika ada)
        if scheduler is not None:
            scheduler.step(val_loss)

        # Simpan history
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)

        elapsed = time.time() - t0
        print(f"Epoch [{epoch:3d}/{num_epochs}] "
              f"| Train Loss: {train_loss:.4f}, Acc: {train_acc:.4f} "
              f"| Val Loss: {val_loss:.4f}, Acc: {val_acc:.4f} "
              f"| {elapsed:.1f}s")

        # Simpan model terbaik
        if val_acc > best_val_acc and save_path:
            best_val_acc = val_acc
            torch.save(model.state_dict(), save_path)
            print(f"  ✓ Model terbaik disimpan (Val Acc: {val_acc:.4f})")

    print(f"\nTraining selesai. Best Val Acc: {best_val_acc:.4f}")
    return history


# ── Visualisasi ────────────────────────────────────────────────────────────────

def plot_history(history, save_path=None):
    """
    Plot kurva loss dan akurasi training vs validasi.
    """
    epochs = range(1, len(history['train_loss']) + 1)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # ── Loss ──
    axes[0].plot(epochs, history['train_loss'], 'b-o', label='Train Loss', markersize=4)
    axes[0].plot(epochs, history['val_loss'], 'r-o', label='Val Loss', markersize=4)
    axes[0].set_title('Learning Curve — Loss', fontsize=13, fontweight='bold')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    # ── Akurasi ──
    axes[1].plot(epochs, history['train_acc'], 'b-o', label='Train Acc', markersize=4)
    axes[1].plot(epochs, history['val_acc'], 'r-o', label='Val Acc', markersize=4)
    axes[1].set_title('Learning Curve — Accuracy', fontsize=13, fontweight='bold')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Accuracy')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    axes[1].set_ylim(0, 1.05)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"[Plot] Grafik disimpan ke: {save_path}")
    plt.show()


def plot_confusion_matrix(labels, preds, class_names, save_path=None, max_classes=20):
    """
    Plot confusion matrix. Jika kelas > max_classes, hanya tampilkan top-N.
    """
    cm = confusion_matrix(labels, preds)

    # Jika terlalu banyak kelas, ambil subset
    if len(class_names) > max_classes:
        print(f"[Info] Menampilkan {max_classes} kelas pertama dari {len(class_names)}")
        cm = cm[:max_classes, :max_classes]
        names = class_names[:max_classes]
    else:
        names = class_names

    fig, ax = plt.subplots(figsize=(max(8, len(names)), max(6, len(names) - 2)))
    im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.colorbar(im, ax=ax)

    ax.set_xticks(range(len(names)))
    ax.set_yticks(range(len(names)))
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=8)
    ax.set_yticklabels(names, fontsize=8)
    ax.set_title('Confusion Matrix', fontsize=13, fontweight='bold')
    ax.set_ylabel('Label Asli')
    ax.set_xlabel('Prediksi Model')

    # Anotasi nilai di tiap sel
    thresh = cm.max() / 2.0
    for i in range(len(names)):
        for j in range(len(names)):
            ax.text(j, i, str(cm[i, j]),
                    ha='center', va='center', fontsize=7,
                    color='white' if cm[i, j] > thresh else 'black')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"[Plot] Confusion matrix disimpan ke: {save_path}")
    plt.show()
