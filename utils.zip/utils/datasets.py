"""
utils/datasets.py
-----------------
Custom Dataset untuk memuat gambar dari struktur folder.

Struktur folder yang diharapkan:
    root_dir/
        kelas_a/
            gambar001.jpg
            gambar002.jpg
        kelas_b/
            gambarXYZ.jpg
"""

import os
from PIL import Image
from torch.utils.data import Dataset


class CustomImageDataset(Dataset):
    """
    Dataset kustom yang memuat gambar dari folder berstruktur kelas.

    Args:
        root_dir  : path ke folder root yang berisi subfolder per kelas
        transform : torchvision transform yang akan diterapkan ke gambar
    """

    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform

        # Ambil semua nama subfolder sebagai nama kelas, diurutkan alfabetis
        self.classes = sorted([
            d for d in os.listdir(root_dir)
            if os.path.isdir(os.path.join(root_dir, d))
        ])

        if len(self.classes) == 0:
            raise ValueError(
                f"Tidak ada subfolder di '{root_dir}'.\n"
                "Pastikan struktur folder: root_dir/nama_kelas/gambar.jpg"
            )

        # Pemetaan: nama kelas → indeks angka
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}

        # Kumpulkan semua path gambar beserta labelnya
        self.image_paths = []
        for cls in self.classes:
            cls_folder = os.path.join(root_dir, cls)
            for fname in sorted(os.listdir(cls_folder)):
                if fname.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.webp')):
                    path = os.path.join(cls_folder, fname)
                    self.image_paths.append((path, self.class_to_idx[cls]))

        print(f"[Dataset] Ditemukan {len(self.classes)} kelas, "
              f"{len(self.image_paths)} gambar total.")

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        path, label = self.image_paths[idx]
        image = Image.open(path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label

    def get_class_names(self):
        """Kembalikan daftar nama kelas."""
        return self.classes
