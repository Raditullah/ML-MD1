"""
scripts/train_mlp.py
--------------------
Latih MLP sederhana pada dataset simulasi 2D.

Jalankan:
    python scripts/train_mlp.py

Apa yang dilakukan:
    1. Buat 500 titik data 2D sintetis (2 kelas)
    2. Normalisasi input
    3. Definisi & latih MLP 1 hidden layer
    4. Tampilkan loss dan akurasi per epoch
    5. Simpan grafik ke outputs/
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt
import numpy as np

from models.mlp import SimpleMLP

# ── Konfigurasi ───────────────────────────────────────────────────────────────
SEED        = 42
N_SAMPLES   = 500
HIDDEN_DIM  = 64
BATCH_SIZE  = 32
LR          = 0.1
EPOCHS      = 50
OUTPUT_DIR  = "outputs"

os.makedirs(OUTPUT_DIR, exist_ok=True)
torch.manual_seed(SEED)
np.random.seed(SEED)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[Device] Menggunakan: {device}")


# ── 1. Buat Dataset Simulasi ──────────────────────────────────────────────────
print("\n[Step 1] Membuat dataset simulasi 2D ...")
X = torch.randn(N_SAMPLES, 2)
# Label 1 jika x1*x2 > 0 (kuadran 1 & 3), label 0 jika sebaliknya
y = (X[:, 0] * X[:, 1] > 0).long()

print(f"  Total sampel : {N_SAMPLES}")
print(f"  Kelas 0 (negatif): {(y == 0).sum().item()}")
print(f"  Kelas 1 (positif): {(y == 1).sum().item()}")

# Normalisasi input
mean = X.mean(dim=0, keepdim=True)
std  = X.std(dim=0, keepdim=True) + 1e-8
X_norm = (X - mean) / std

# Bagi train/test (80/20)
split = int(0.8 * N_SAMPLES)
X_train, X_test = X_norm[:split], X_norm[split:]
y_train, y_test = y[:split], y[split:]

train_loader = DataLoader(TensorDataset(X_train, y_train),
                          batch_size=BATCH_SIZE, shuffle=True)
test_loader  = DataLoader(TensorDataset(X_test, y_test),
                          batch_size=BATCH_SIZE, shuffle=False)


# ── 2. Definisi Model ─────────────────────────────────────────────────────────
print("\n[Step 2] Inisialisasi model MLP ...")
model     = SimpleMLP(input_dim=2, hidden_dim=HIDDEN_DIM, num_classes=2).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=LR, momentum=0.9)

total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"  Arsitektur : Input(2) → FC({HIDDEN_DIM}) → ReLU → FC(2)")
print(f"  Total param: {total_params}")


# ── 3. Training Loop ──────────────────────────────────────────────────────────
print(f"\n[Step 3] Training {EPOCHS} epoch ...\n")

train_losses, train_accs = [], []

for epoch in range(1, EPOCHS + 1):
    model.train()
    total_loss = 0.0
    correct = total = 0

    for xb, yb in train_loader:
        xb, yb = xb.to(device), yb.to(device)

        # ── Forward ──
        logits = model(xb)
        loss   = criterion(logits, yb)

        # ── Backward ──
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * xb.size(0)
        _, preds = torch.max(logits, 1)
        correct  += (preds == yb).sum().item()
        total    += yb.size(0)

    avg_loss = total_loss / total
    acc      = correct / total
    train_losses.append(avg_loss)
    train_accs.append(acc)

    if epoch % 5 == 0 or epoch == 1:
        print(f"  Epoch {epoch:3d}/{EPOCHS} | Loss: {avg_loss:.4f} | Akurasi Train: {acc:.4f}")


# ── 4. Evaluasi pada Test Set ─────────────────────────────────────────────────
print("\n[Step 4] Evaluasi pada test set ...")
model.eval()
with torch.no_grad():
    correct = total = 0
    for xb, yb in test_loader:
        xb, yb = xb.to(device), yb.to(device)
        _, preds = torch.max(model(xb), 1)
        correct += (preds == yb).sum().item()
        total   += yb.size(0)

test_acc = correct / total
print(f"  Akurasi Test: {test_acc:.4f}")


# ── 5. Simpan Grafik ──────────────────────────────────────────────────────────
print("\n[Step 5] Menyimpan grafik ...")

fig, axes = plt.subplots(1, 2, figsize=(12, 4))

axes[0].plot(train_losses, 'b-', linewidth=1.5)
axes[0].set_title('Training Loss', fontweight='bold')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Loss')
axes[0].grid(True, alpha=0.3)

axes[1].plot(train_accs, 'g-', linewidth=1.5)
axes[1].axhline(y=test_acc, color='r', linestyle='--', label=f'Test Acc: {test_acc:.4f}')
axes[1].set_title('Training Accuracy', fontweight='bold')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Accuracy')
axes[1].legend()
axes[1].grid(True, alpha=0.3)
axes[1].set_ylim(0, 1.05)

plt.suptitle('MLP Sederhana — Dataset Simulasi 2D', fontsize=13, fontweight='bold')
plt.tight_layout()

save_path = os.path.join(OUTPUT_DIR, "mlp_training_curves.png")
plt.savefig(save_path, dpi=150, bbox_inches='tight')
print(f"  Grafik disimpan ke: {save_path}")
plt.show()

print("\n✅ Selesai! Cek folder outputs/ untuk grafik.")
