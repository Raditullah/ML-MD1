"""
scripts/mnist_app.py
---------------------
Studi Kasus MNIST: Latih CNN bergaya LeNet + GUI interaktif.

Jalankan:
    python scripts/mnist_app.py

Workflow:
    1. Jika model belum ada → latih otomatis (~5-10 menit)
    2. Buka jendela GUI
    3. Gambar angka 0-9 dengan mouse
    4. Klik "Klasifikasi" untuk melihat prediksi
    5. Klik "Hapus" untuk membersihkan kanvas
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from PIL import Image, ImageOps

# ── Konfigurasi ───────────────────────────────────────────────────────────────
MODEL_PATH  = os.path.join("outputs", "mnist_lenet.pth")
EPOCHS      = 15
BATCH_SIZE  = 128
LR          = 1e-3
BRUSH_SIZE  = 14
CANVAS_SIZE = 280
NORM_MEAN   = (0.1307,)
NORM_STD    = (0.3081,)

os.makedirs("outputs", exist_ok=True)


# ── Definisi Model (CNN Bergaya LeNet) ────────────────────────────────────────
class LeNetMNIST(nn.Module):
    """
    CNN bergaya LeNet modern untuk MNIST.
    
    Arsitektur:
        Conv(1→32) → BN → ReLU → Conv(32→32) → BN → ReLU → MaxPool → Dropout
        Conv(32→64) → BN → ReLU → Conv(64→64) → BN → ReLU → MaxPool → Dropout
        Flatten → FC(3136→256) → BN → ReLU → Dropout → FC(256→10)
    """
    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            # Block 1
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), nn.Dropout2d(0.25),
            # Block 2
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), nn.Dropout2d(0.25),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 256),
            nn.BatchNorm1d(256), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


# ── Transform ─────────────────────────────────────────────────────────────────
def get_train_transform():
    return transforms.Compose([
        transforms.RandomAffine(degrees=10, translate=(0.1, 0.1)),
        transforms.ToTensor(),
        transforms.Normalize(NORM_MEAN, NORM_STD),
    ])

def get_infer_transform():
    return transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(NORM_MEAN, NORM_STD),
    ])


# ── Training ──────────────────────────────────────────────────────────────────
def train_model(device):
    print(f"[Train] Melatih pada: {device}")
    print("[Train] Download MNIST (jika belum ada) ...")

    train_ds = datasets.MNIST(root=".", train=True,  download=True, transform=get_train_transform())
    val_ds   = datasets.MNIST(root=".", train=False, download=True, transform=get_infer_transform())

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,  num_workers=0)
    val_loader   = DataLoader(val_ds,   batch_size=256,         shuffle=False, num_workers=0)

    model     = LeNetMNIST().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LR, weight_decay=1e-4)
    best_acc  = 0.0

    for epoch in range(1, EPOCHS + 1):
        # Training
        model.train()
        for data, target in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            loss = criterion(model(data), target)
            loss.backward()
            optimizer.step()

        # Validasi
        model.eval()
        correct = total = 0
        with torch.no_grad():
            for data, target in val_loader:
                data, target = data.to(device), target.to(device)
                correct += model(data).argmax(1).eq(target).sum().item()
                total   += data.size(0)
        val_acc = correct / total
        print(f"  Epoch {epoch}/{EPOCHS} | Val Acc = {val_acc:.4f}")

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save(model.state_dict(), MODEL_PATH)

    print(f"\n[Train] Selesai! Best Val Acc: {best_acc:.4f}")
    print(f"[Train] Model disimpan ke: {MODEL_PATH}")

    # Muat ulang ke CPU untuk GUI
    cpu_model = LeNetMNIST()
    cpu_model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
    cpu_model.eval()
    return cpu_model


# ── Load Model ────────────────────────────────────────────────────────────────
def load_model():
    model = LeNetMNIST()
    if not os.path.exists(MODEL_PATH):
        print("[Info] Model belum ada, mulai training otomatis ...")
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return train_model(device)
    model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
    model.eval()
    print(f"[Info] Model dimuat dari: {MODEL_PATH}")
    return model


# ── Preprocessing Gambar dari Kanvas ─────────────────────────────────────────
def preprocess_canvas(surface):
    """
    Konversi gambar dari kanvas pygame ke tensor yang siap diproses model.
    Langkah: RGB → Grayscale → Invert → Crop → Padding → Resize ke 28x28
    """
    import pygame
    raw = pygame.surfarray.array3d(surface)        # (W, H, 3)
    img = Image.fromarray(raw.transpose(1, 0, 2))  # (H, W, 3)
    img = img.convert("L")
    img = ImageOps.invert(img)                     # MNIST: putih di hitam

    bbox = img.getbbox()
    if bbox is None:
        blank = Image.new("L", (28, 28), 0)
        return get_infer_transform()(blank).unsqueeze(0)

    img       = img.crop(bbox)
    max_side  = max(img.size)
    margin    = max_side // 4
    new_size  = max_side + 2 * margin
    padded    = Image.new("L", (new_size, new_size), 0)
    offset    = ((new_size - img.size[0]) // 2, (new_size - img.size[1]) // 2)
    padded.paste(img, offset)
    img_28    = padded.resize((28, 28), Image.LANCZOS)
    return get_infer_transform()(img_28).unsqueeze(0)


# ── GUI Kelas Tombol ──────────────────────────────────────────────────────────
class Button:
    def __init__(self, label, x, y, w, h, color):
        import pygame
        self.rect  = pygame.Rect(x, y, w, h)
        self.label = label
        self.color = color

    def draw(self, screen, font):
        import pygame
        pygame.draw.rect(screen, self.color, self.rect, border_radius=6)
        screen.blit(font.render(self.label, True, (0, 0, 0)),
                    (self.rect.x + 10, self.rect.y + 8))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)


# ── GUI Utama ─────────────────────────────────────────────────────────────────
def run_gui(model):
    try:
        import pygame
    except ImportError:
        print("⚠️  pygame tidak terinstal. Jalankan: pip install pygame")
        return

    pygame.init()
    screen   = pygame.display.set_mode((460, 300))
    pygame.display.set_caption("🎨 Klasifikasi Digit MNIST")
    clock    = pygame.time.Clock()
    font     = pygame.font.SysFont(None, 28)
    font_big = pygame.font.SysFont(None, 42)

    canvas   = pygame.Surface((CANVAS_SIZE, CANVAS_SIZE))
    canvas.fill((255, 255, 255))

    classify_btn = Button("Klasifikasi", 295, 20,  155, 40, (50, 200, 80))
    clear_btn    = Button("Hapus",       295, 70,  155, 40, (220, 60, 60))

    pred_text = "Gambar angka"
    conf_text = "lalu klik Klasifikasi"
    drawing   = False
    last_pos  = None

    print("\n[GUI] Jendela GUI terbuka!")
    print("  - Gambar angka 0-9 dengan mouse kiri")
    print("  - Klik 'Klasifikasi' untuk melihat prediksi")
    print("  - Klik 'Hapus' untuk membersihkan kanvas\n")

    while True:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if classify_btn.is_clicked(mouse_pos):
                    # Prediksi
                    x = preprocess_canvas(canvas)
                    with torch.no_grad():
                        probs = torch.softmax(model(x), dim=1)
                        pred  = probs.argmax(1).item()
                        conf  = probs.max().item()
                    pred_text = f"Angka: {pred}"
                    conf_text = f"Keyakinan: {conf*100:.1f}%"
                    print(f"  Prediksi: {pred} ({conf*100:.1f}%)")

                elif clear_btn.is_clicked(mouse_pos):
                    canvas.fill((255, 255, 255))
                    pred_text = "Gambar angka"
                    conf_text = "lalu klik Klasifikasi"

                elif mouse_pos[0] < CANVAS_SIZE:
                    drawing  = True
                    last_pos = mouse_pos

            elif event.type == pygame.MOUSEBUTTONUP:
                drawing = False

            elif event.type == pygame.MOUSEMOTION and drawing:
                if last_pos and last_pos[0] < CANVAS_SIZE:
                    pygame.draw.line(canvas, (0, 0, 0), last_pos, mouse_pos, BRUSH_SIZE)
                last_pos = mouse_pos

        # Render
        screen.fill((40, 40, 40))
        screen.blit(canvas, (0, 0))
        pygame.draw.rect(screen, (100, 100, 100), (0, 0, CANVAS_SIZE, CANVAS_SIZE), 2)

        screen.blit(font_big.render(pred_text, True, (255, 220, 50)),  (293, 130))
        screen.blit(font.render(conf_text,     True, (180, 220, 255)), (293, 175))
        screen.blit(font.render("Canvas: 280x280", True, (150, 150, 150)), (293, 260))

        classify_btn.draw(screen, font)
        clear_btn.draw(screen, font)

        pygame.display.flip()
        clock.tick(60)


# ── Entry Point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("  MNIST Digit Classifier — LeNet CNN")
    print("=" * 50)

    model = load_model()
    run_gui(model)
