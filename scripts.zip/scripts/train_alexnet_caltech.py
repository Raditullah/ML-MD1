"""
scripts/train_alexnet_caltech.py
---------------------------------
Latih AlexNet (transfer learning dari ImageNet) pada dataset custom
kucing / anjing / kelinci.

Struktur yang diharapkan:
    data/dataset_kustom/
        kucing/gambar.jpg
        anjing/gambar.jpg
        kelinci/gambar.jpg

Jalankan:
    python scripts/train_alexnet_caltech.py

Output:
    outputs/alexnet_caltech.pth   ← bobot model terbaik
    outputs/alexnet_curves.png    ← grafik loss & akurasi
    outputs/alexnet_cm.png        ← confusion matrix
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from sklearn.metrics import classification_report

from models.alexnet import AlexNet, count_parameters
from utils.datasets import CustomImageDataset
from utils.training_loops import train_model, evaluate, plot_history, plot_confusion_matrix

# ── Konfigurasi ───────────────────────────────────────────────────────────────
DATA_DIR    = "data/dataset_kustom"
OUTPUT_DIR  = "outputs"
MODEL_PATH  = os.path.join(OUTPUT_DIR, "alexnet_caltech.pth")
BATCH_SIZE  = 32
LR          = 1e-3     # dinaikkan: classifier dilatih dari nol (features dibekukan)
EPOCHS      = 20        # dinaikkan: beri waktu classifier belajar 3 kelas kita
VAL_SPLIT   = 0.2
SEED        = 42

os.makedirs(OUTPUT_DIR, exist_ok=True)
torch.manual_seed(SEED)

device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print(f"[Device] Menggunakan: {device}")


# =====================================================
if not os.path.exists(DATA_DIR):
    print(f"\n⚠️  Folder '{DATA_DIR}' tidak ditemukan!")
    print("   Pastikan folder dataset_kustom berisi subfolder per kelas")
    print("   (misal: kucing/, anjing/, kelinci/) dengan gambar di dalamnya.\n")
    sys.exit(1)

# ── 1. Persiapan Data ─────────────────────────────────────────────────────────
print("\n[Step 1] Memuat dataset ...")

data_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),           # Augmentasi: flip horizontal
    transforms.RandomRotation(10),               # Augmentasi: rotasi ±10°
    transforms.ColorJitter(brightness=0.2,       # Augmentasi: variasi warna
                           contrast=0.2),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

val_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

# Muat seluruh dataset dengan augmentasi
full_dataset = CustomImageDataset(
    root_dir=DATA_DIR,
    transform=data_transforms
)
class_names  = full_dataset.get_class_names()
num_classes  = len(class_names)
print(f"  Jumlah kelas   : {num_classes}")
print(f"  Total gambar   : {len(full_dataset)}")

# Bagi train/val (80%/20%)
val_size   = int(VAL_SPLIT * len(full_dataset))
train_size = len(full_dataset) - val_size
train_set, val_set = random_split(
    full_dataset, [train_size, val_size],
    generator=torch.Generator().manual_seed(SEED)
)

# Terapkan transform yang berbeda untuk val (tanpa augmentasi)
val_set.dataset.transform = val_transforms

train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True,
                          num_workers=0, pin_memory=True)
val_loader   = DataLoader(val_set, batch_size=BATCH_SIZE, shuffle=False,
                          num_workers=0, pin_memory=True)

print(f"  Train set      : {train_size} gambar")
print(f"  Val set        : {val_size} gambar")


# ── 2. Inisialisasi Model ─────────────────────────────────────────────────────
print("\n[Step 2] Inisialisasi model AlexNet ...")
model = AlexNet(num_classes=num_classes).to(device)
print(f"  Total parameter: {count_parameters(model):,}")

criterion = nn.CrossEntropyLoss()
# Hanya latih parameter yang requires_grad=True (classifier), karena
# bagian features sudah dibekukan (pretrained dari ImageNet)
trainable_params = filter(lambda p: p.requires_grad, model.parameters())
optimizer = optim.Adam(trainable_params, lr=LR, weight_decay=1e-4)

# Learning rate scheduler: turunkan LR jika val_loss tidak membaik
scheduler = optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, 
    mode='min', 
    factor=0.1, 
    patience=5
)


# ── 3. Training ───────────────────────────────────────────────────────────────
print(f"\n[Step 3] Training {EPOCHS} epoch ...")
history = train_model(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    criterion=criterion,
    optimizer=optimizer,
    num_epochs=EPOCHS,
    device=device,
    save_path=MODEL_PATH,
    scheduler=scheduler,
)


# ── 4. Evaluasi Final ─────────────────────────────────────────────────────────
print("\n[Step 4] Evaluasi final pada val set ...")

# Muat model terbaik
if os.path.exists(MODEL_PATH):
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))

val_acc, val_loss, all_preds, all_labels = evaluate(model, val_loader, device)
print(f"\n  Val Accuracy : {val_acc:.4f}")
print(f"  Val Loss     : {val_loss:.4f}")


# ── 5. Simpan Visualisasi ─────────────────────────────────────────────────────
print("\n[Step 5] Menyimpan grafik dan confusion matrix ...")

plot_history(history, save_path=os.path.join(OUTPUT_DIR, "alexnet_curves.png"))

plot_confusion_matrix(
    labels=all_labels,
    preds=all_preds,
    class_names=class_names,
    save_path=os.path.join(OUTPUT_DIR, "alexnet_cm.png"),
    max_classes=20,
)

# Classification report (teks)
report = classification_report(
    all_labels, all_preds,
    target_names=class_names,
    zero_division=0
)
report_path = os.path.join(OUTPUT_DIR, "alexnet_report.txt")
with open(report_path, "w") as f:
    f.write(report)
print(f"\n  Classification report disimpan ke: {report_path}")

print("\n✅ Training selesai! Semua output tersimpan di folder outputs/")
print(f"   Model  : {MODEL_PATH}")
print(f"   Grafik : outputs/alexnet_curves.png")
print(f"   CM     : outputs/alexnet_cm.png")