"""
lab3_fastapi/test_api.py
------------------------
Script untuk menguji API FastAPI menggunakan library requests.

Jalankan (pastikan server sudah jalan dulu):
    uvicorn app:app --reload

Lalu di terminal lain:
    python test_api.py
"""

import sys
import os
import requests
import json
from PIL import Image
import io

BASE_URL = "http://127.0.0.1:8000"


def test_health():
    """Test endpoint /health"""
    print("=" * 40)
    print("TEST 1: Health Check")
    r = requests.get(f"{BASE_URL}/health")
    data = r.json()
    print(f"  Status        : {r.status_code}")
    print(f"  Model loaded  : {data.get('model_loaded')}")
    print(f"  Model type    : {data.get('model_type')}")
    print(f"  Num classes   : {data.get('num_classes')}")
    return data.get('model_loaded', False)


def create_test_image():
    """Buat gambar test sederhana (kotak hitam di atas putih)"""
    img = Image.new("RGB", (28, 28), color=(255, 255, 255))
    # Gambar angka "1" sederhana secara manual
    pixels = img.load()
    for y in range(5, 23):
        pixels[14, y] = (0, 0, 0)
        pixels[13, y] = (0, 0, 0)
    return img


def test_predict_bytes(image: Image.Image):
    """Test endpoint /predict dengan gambar dari memori"""
    print("=" * 40)
    print("TEST 2: Predict Endpoint")

    buf = io.BytesIO()
    image.save(buf, format="PNG")
    buf.seek(0)

    r = requests.post(
        f"{BASE_URL}/predict",
        files={"file": ("test.png", buf, "image/png")}
    )

    if r.status_code == 200:
        data = r.json()
        print(f"  Status          : {r.status_code} ✓")
        print(f"  Prediksi kelas  : {data['predicted_class']}")
        print(f"  Keyakinan       : {data['confidence']*100:.1f}%")
        print(f"  Latensi         : {data['latency_ms']} ms")
        print(f"\n  Top 5 Prediksi  :")
        for item in data['top5']:
            bar = "█" * int(item['score'] * 30)
            print(f"    {item['class']:20s} {item['score']*100:5.1f}% {bar}")
    else:
        print(f"  Error {r.status_code}: {r.text}")


def test_predict_file(filepath: str):
    """Test /predict dengan file gambar dari disk"""
    print("=" * 40)
    print(f"TEST 3: Predict dari file: {filepath}")

    if not os.path.exists(filepath):
        print(f"  ⚠️  File tidak ditemukan: {filepath}")
        return

    with open(filepath, "rb") as f:
        r = requests.post(
            f"{BASE_URL}/predict",
            files={"file": (os.path.basename(filepath), f, "image/jpeg")}
        )

    if r.status_code == 200:
        data = r.json()
        print(f"  Prediksi: {data['predicted_class']} ({data['confidence']*100:.1f}%)")
    else:
        print(f"  Error: {r.text}")


def test_invalid_file():
    """Test dengan file yang bukan gambar → harusnya error 400"""
    print("=" * 40)
    print("TEST 4: Invalid File (ekspektasi error 400)")

    r = requests.post(
        f"{BASE_URL}/predict",
        files={"file": ("test.txt", b"bukan gambar", "text/plain")}
    )
    print(f"  Status: {r.status_code} ({'✓ error ditangkap' if r.status_code == 400 else '✗ tidak sesuai ekspektasi'})")


if __name__ == "__main__":
    print("\n🔧 Testing PADL M1 FastAPI Server")
    print(f"   URL: {BASE_URL}\n")

    try:
        loaded = test_health()
        print()

        if loaded:
            img = create_test_image()
            test_predict_bytes(img)
            print()

            # Jika ada file gambar sebagai argumen
            if len(sys.argv) > 1:
                test_predict_file(sys.argv[1])
                print()

        test_invalid_file()

        print("\n✅ Semua test selesai!")

    except requests.exceptions.ConnectionError:
        print("❌ Tidak bisa terhubung ke server!")
        print("   Pastikan server sudah jalan: uvicorn app:app --reload")
