"""
lab3_fastapi/app.py  (VERSI FIX)
---------------------------------
Deploy model PyTorch sebagai REST API menggunakan FastAPI.

Struktur folder yang diharapkan:
    MD1/
    ├── lab3_fastapi/
    │   ├── app.py          ← file ini
    │   └── templates/
    │       └── index.html
    ├── models/
    │   └── alexnet.py
    ├── scripts/
    │   └── mnist_app.py
    ├── data/
    │   └── dataset_kustom/
    └── outputs/
        ├── mnist_lenet.pth
        └── alexnet_caltech.pth

Jalankan dari folder MD1/ (ROOT project):
    uvicorn lab3_fastapi.app:app --reload

Atau dari dalam folder lab3_fastapi/:
    cd lab3_fastapi
    uvicorn app:app --reload

Buka browser: http://127.0.0.1:8000
Swagger docs: http://127.0.0.1:8000/docs
"""

import os
import sys
import io
import time

# ── Tambahkan root project ke sys.path ────────────────────────────────────────
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)   # folder MD1/
sys.path.insert(0, ROOT_DIR)

import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request

# ── Path Konfigurasi ──────────────────────────────────────────────────────────
OUTPUTS_DIR  = os.path.join(ROOT_DIR, "outputs")
MNIST_PATH   = os.path.join(OUTPUTS_DIR, "mnist_lenet.pth")
CALTECH_PATH = os.path.join(OUTPUTS_DIR, "alexnet_caltech.pth")
CUSTOM_DIR   = os.path.join(ROOT_DIR, "data", "dataset_kustom")

# ── Pilih model: "mnist" atau "custom" ───────────────────────────────────────
# Ganti ke "custom" jika ingin pakai AlexNet + dataset_kustom
MODEL_TYPE = "custom"


# ── Definisi LeNetMNIST ───────────────────────────────────────────────────────
class LeNetMNIST(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), nn.Dropout2d(0.25),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2), nn.Dropout2d(0.25),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 256),
            nn.BatchNorm1d(256), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes),
        )
    def forward(self, x):
        return self.classifier(self.features(x))


# ── Definisi AlexNet (untuk dataset_kustom) ───────────────────────────────────
class AlexNetCustom(nn.Module):
    def __init__(self, num_classes=101):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2), nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(64, 192, kernel_size=5, padding=2), nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(256 * 6 * 6, 4096), nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(4096, 4096), nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )
    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


# ── FastAPI App ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="PADL M1 — Model Inference API",
    description="API inferensi model deep learning (MNIST / Dataset Kustom)",
    version="2.0",
)

TEMPLATES_DIR = os.path.join(THIS_DIR, "templates")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# State global
state = {
    "model":       None,
    "class_names": [],
    "loaded":      False,
    "model_type":  MODEL_TYPE,
    "model_path":  "",
}


# ── Startup: Load Model ───────────────────────────────────────────────────────
@app.on_event("startup")
def load_model_on_startup():
    print("\n" + "="*55)
    print("  PADL M1 FastAPI — Startup")
    print("="*55)
    print(f"  ROOT_DIR    : {ROOT_DIR}")
    print(f"  OUTPUTS_DIR : {OUTPUTS_DIR}")
    print(f"  MODEL_TYPE  : {MODEL_TYPE}")
    print(f"  MNIST_PATH  : {MNIST_PATH}")
    print(f"  EXISTS?     : {os.path.exists(MNIST_PATH)}")
    print()

    if MODEL_TYPE == "mnist":
        _load_mnist()
    else:
        _load_custom()


def _load_mnist():
    if not os.path.exists(MNIST_PATH):
        print(f"⚠️  File tidak ditemukan: {MNIST_PATH}")
        print("   Jalankan dulu: python scripts/mnist_app.py")
        return
    try:
        mdl = LeNetMNIST(num_classes=10)
        mdl.load_state_dict(torch.load(MNIST_PATH, map_location="cpu"))
        mdl.eval()

        state["model"]       = mdl
        state["class_names"] = [str(i) for i in range(10)]
        state["loaded"]      = True
        state["model_type"]  = "mnist"
        state["model_path"]  = MNIST_PATH
        print(f"✅ Model MNIST dimuat: {MNIST_PATH}")
    except Exception as e:
        print(f"❌ Gagal load MNIST: {e}")


def _load_custom():
    class_names = []
    if os.path.exists(CUSTOM_DIR):
        class_names = sorted([
            d for d in os.listdir(CUSTOM_DIR)
            if os.path.isdir(os.path.join(CUSTOM_DIR, d))
        ])
        print(f"  Kelas dataset_kustom ({len(class_names)}): {class_names}")
    else:
        print(f"⚠️  Folder dataset_kustom tidak ada: {CUSTOM_DIR}")
        class_names = [f"kelas_{i}" for i in range(10)]

    if not os.path.exists(CALTECH_PATH):
        print(f"⚠️  File tidak ditemukan: {CALTECH_PATH}")
        print("   Jalankan dulu: python scripts/train_alexnet_caltech.py")
        return
    try:
        mdl = AlexNetCustom(num_classes=len(class_names))
        mdl.load_state_dict(torch.load(CALTECH_PATH, map_location="cpu"))
        mdl.eval()

        state["model"]       = mdl
        state["class_names"] = class_names
        state["loaded"]      = True
        state["model_type"]  = "custom"
        state["model_path"]  = CALTECH_PATH
        print(f"✅ Model Custom dimuat: {CALTECH_PATH}")
    except Exception as e:
        print(f"❌ Gagal load Custom: {e}")


# ── Transform ─────────────────────────────────────────────────────────────────
def get_transform():
    if state["model_type"] == "mnist":
        return transforms.Compose([
            transforms.Grayscale(num_output_channels=1),
            transforms.Resize((28, 28)),
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,)),
        ])
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        ),
    ])


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/")
def halaman_utama(request: Request):
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "model_type": state["model_type"],
            "loaded": state["loaded"],
        }
    )


@app.get("/health")
async def health_check():
    return {
        "status":       "ok",
        "model_loaded": state["loaded"],
        "model_type":   state["model_type"],
        "num_classes":  len(state["class_names"]),
        "class_names":  state["class_names"],
        "model_path":   state["model_path"],
    }


@app.get("/classes")
async def get_classes():
    return {
        "num_classes": len(state["class_names"]),
        "class_names": state["class_names"],
    }


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """
    Upload gambar → dapat prediksi lengkap.

    Response JSON:
    {
        "predicted_class" : "5",
        "predicted_index" : 5,
        "confidence"      : 0.9876,
        "confidence_pct"  : "98.76%",
        "top5"            : [...],
        "all_scores"      : {"0": 0.001, ...},
        "latency_ms"      : 12.5,
        "model_type"      : "mnist",
        "filename"        : "gambar.png",
        "image_size"      : "280x280"
    }
    """
    # Cek model
    if not state["loaded"]:
        raise HTTPException(
            status_code=503,
            detail=(
                "Model belum dimuat! "
                f"Cek apakah file .pth ada di: {OUTPUTS_DIR}. "
                "Jalankan training dulu lalu restart server."
            )
        )

    # Cek tipe file
    allowed = ["image/jpeg", "image/png", "image/bmp", "image/webp"]
    if file.content_type not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Tipe '{file.content_type}' tidak didukung. Pakai: JPG/PNG/BMP/WebP"
        )

    try:
        # Baca gambar
        contents = await file.read()
        image    = Image.open(io.BytesIO(contents)).convert("RGB")

        # Transform
        tensor = get_transform()(image).unsqueeze(0)  # (1, C, H, W)

        # Inferensi
        t0 = time.time()
        with torch.no_grad():
            logits = state["model"](tensor)
            probs  = torch.softmax(logits, dim=1)[0]
        latency_ms = round((time.time() - t0) * 1000, 2)

        # Hasil
        class_names    = state["class_names"]
        pred_idx       = int(probs.argmax().item())
        pred_class     = class_names[pred_idx]
        confidence     = round(float(probs[pred_idx].item()), 6)
        confidence_pct = f"{confidence * 100:.2f}%"

        # Top-5
        k = min(5, len(class_names))
        top_scores, top_indices = torch.topk(probs, k)
        top5 = [
            {
                "rank":  i + 1,
                "class": class_names[int(idx.item())],
                "index": int(idx.item()),
                "score": round(float(score.item()), 6),
                "pct":   f"{float(score.item()) * 100:.2f}%",
            }
            for i, (score, idx) in enumerate(zip(top_scores, top_indices))
        ]

        # Semua skor
        all_scores = {
            class_names[i]: round(float(probs[i].item()), 6)
            for i in range(len(class_names))
        }

        print(f"[Predict] {file.filename} → {pred_class} ({confidence_pct}) | {latency_ms}ms")

        return JSONResponse({
            "predicted_class": pred_class,
            "predicted_index": pred_idx,
            "confidence":      confidence,
            "confidence_pct":  confidence_pct,
            "top5":            top5,
            "all_scores":      all_scores,
            "latency_ms":      latency_ms,
            "model_type":      state["model_type"],
            "filename":        file.filename,
            "image_size":      f"{image.width}x{image.height}",
        })

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error saat memproses gambar: {str(e)}"
        )