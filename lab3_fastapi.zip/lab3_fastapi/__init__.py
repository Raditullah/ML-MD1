# lab3_fastapi package
