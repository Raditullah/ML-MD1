"""
models/mlp.py
-------------
Definisi model MLP (Multi-Layer Perceptron) sederhana.
Digunakan untuk klasifikasi umum dengan input vektor 1D.
"""

import torch
import torch.nn as nn


class SimpleMLP(nn.Module):
    """
    MLP dengan satu hidden layer.

    Arsitektur:
        Input (input_dim) → Linear → ReLU → Linear → Output (num_classes)

    Args:
        input_dim  : jumlah fitur input (misal: 2 untuk data 2D)
        hidden_dim : jumlah neuron di hidden layer
        num_classes: jumlah kelas output
    """

    def __init__(self, input_dim=2, hidden_dim=64, num_classes=2):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        # Forward propagation: input → hidden → output
        h = self.act(self.fc1(x))   # h = ReLU(W1*x + b1)
        out = self.fc2(h)           # out = W2*h + b2
        return out


class DeepMLP(nn.Module):
    """
    MLP lebih dalam dengan Batch Normalization dan Dropout.
    Cocok untuk dataset yang lebih kompleks.

    Args:
        input_dim   : jumlah fitur input
        hidden_dims : list jumlah neuron per hidden layer, misal [128, 64, 32]
        num_classes : jumlah kelas output
        dropout_p   : probabilitas dropout (0.0 = nonaktif)
    """

    def __init__(self, input_dim=2, hidden_dims=[128, 64], num_classes=2, dropout_p=0.3):
        super().__init__()
        layers = []
        prev_dim = input_dim

        for h_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, h_dim))
            layers.append(nn.BatchNorm1d(h_dim))
            layers.append(nn.ReLU())
            if dropout_p > 0:
                layers.append(nn.Dropout(dropout_p))
            prev_dim = h_dim

        layers.append(nn.Linear(prev_dim, num_classes))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


if __name__ == "__main__":
    # Test sederhana: pastikan dimensi output benar
    model = SimpleMLP(input_dim=2, hidden_dim=16, num_classes=2)
    x = torch.randn(8, 2)  # batch 8 sampel, 2 fitur
    out = model(x)
    print(f"[SimpleMLP] Input shape: {x.shape} → Output shape: {out.shape}")

    model2 = DeepMLP(input_dim=2, hidden_dims=[64, 32], num_classes=3)
    out2 = model2(x[:, :2])
    print(f"[DeepMLP]   Input shape: {x.shape} → Output shape: {out2.shape}")
