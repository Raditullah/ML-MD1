import torch
import torch.nn as nn
from torchvision import models


class AlexNet(nn.Module):
    """
    AlexNet dengan Transfer Learning.

    Menggunakan bobot AlexNet yang sudah dilatih di ImageNet (1.2 juta gambar),
    lalu hanya melatih ulang bagian classifier untuk kelas-kelas custom kita
    (kucing / anjing / kelinci).

    Kenapa ini penting: dataset custom kita cuma punya puluhan-ratusan gambar
    per kelas. Melatih AlexNet dari nol (random weights) dengan data sekecil
    itu membuat model tidak sempat belajar fitur dasar (tepi, tekstur, bentuk)
    dan hasilnya nebak-nebak / akurasi rendah. Dengan transfer learning, model
    sudah "bisa melihat" sejak awal, tinggal belajar membedakan 3 kelas kita.

    Parameter:
        num_classes     : jumlah kelas output (3 untuk kucing/anjing/kelinci)
        freeze_features : True = bekukan seluruh bagian convolutional
                          (features), hanya classifier yang dilatih.
                          Cocok untuk dataset kecil.
    """
    def __init__(self, num_classes=101, freeze_features=True):
        super(AlexNet, self).__init__()

        # Muat AlexNet pretrained dari ImageNet
        base = models.alexnet(weights=models.AlexNet_Weights.IMAGENET1K_V1)

        self.features = base.features
        self.avgpool  = base.avgpool

        # Bekukan seluruh feature extractor (convolutional layers)
        if freeze_features:
            for param in self.features.parameters():
                param.requires_grad = False

        # Classifier baru, disesuaikan dengan jumlah kelas kita
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


if __name__ == "__main__":
    # Test model
    model = AlexNet(num_classes=3)
    x = torch.randn(2, 3, 224, 224)
    out = model(x)
    print(f"Input  shape          : {x.shape}")
    print(f"Output shape          : {out.shape}")
    print(f"Total params (dilatih): {count_parameters(model):,}")