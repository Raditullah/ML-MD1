from .mlp import SimpleMLP, DeepMLP
# models/__init__.py
from .alexnet import AlexNet